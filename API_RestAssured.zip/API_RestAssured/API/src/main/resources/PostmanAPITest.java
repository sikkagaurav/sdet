import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileInputStream;
import java.io.IOException;

public class PostmanAPITest {
    public static void main(String[] args) {
        String excelFilePath = "path/to/excel/file.xlsx";
        String sheetName = "Sheet1";
        String url = "https://reqres.in/api/register";

        String email = readDataFromExcel(excelFilePath, sheetName, 0, 0);
        String password = readDataFromExcel(excelFilePath, sheetName, 0, 1);

        Response response = RestAssured.given()
                .contentType("application/json")
                .body("{\"email\": \"" + email + "\", \"password\": \"" + password + "\"}")
                .post(url);

        int id = response.jsonPath().getInt("id");
        String token = response.jsonPath().getString("token");

        // Assertions for positive cases
        assert id > 0;
        assert token != null && !token.isEmpty();

        // Assertions for negative cases
        // Add your assertions here for negative scenarios

        System.out.println("API response: " + response.getBody().asString());
    }

    private static String readDataFromExcel(String excelFilePath, String sheetName, int row, int column) {
        try {
            FileInputStream file = new FileInputStream(excelFilePath);
            Workbook workbook = new XSSFWorkbook(file);
            Sheet sheet = workbook.getSheet(sheetName);
            Row rowData = sheet.getRow(row);
            Cell cell = rowData.getCell(column);
            return cell.getStringCellValue();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}