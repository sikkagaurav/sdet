package com.sadakar.common;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks extends BasePage {

	@Before //Cucumber Before Hook
	public static void setupDriver() throws InterruptedException {
		
		// Set the path to the ChromeDriver executable
				System.setProperty("webdriver.chrome.driver",
						"C:\\Users\\sikkagaurav\\Downloads\\chromedriver-win64\\chromedriver.exe");

				// Create a new instance of the ChromeDriver
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--remote-allow-origins=*");
				driver = new ChromeDriver(options);
				driver.manage().window().maximize();
//				driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
				
	}

	@After // Cucumber After hook
	public static void quitDriver() throws Exception {
		
		driver.quit();
	}

}
