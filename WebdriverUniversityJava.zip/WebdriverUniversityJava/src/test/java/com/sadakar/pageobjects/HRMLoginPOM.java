package com.sadakar.pageobjects;

import org.openqa.selenium.By;

public class HRMLoginPOM {

	// Locators for username, password, loginButton
	public By userNameLocator = By.xpath("//*[@id=\"txtUsername\"]");
	public By passwordLocator = By.xpath("//*[@id=\"txtPassword\"]");
	public By loginButtonLocator = By.id("btnLogin");

}
