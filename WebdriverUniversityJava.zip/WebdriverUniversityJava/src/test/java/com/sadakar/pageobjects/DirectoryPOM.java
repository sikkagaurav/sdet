package com.sadakar.pageobjects;

import org.openqa.selenium.By;

public class DirectoryPOM {

	// locators for view Directory Page/Tab, Search button
	public By viewDirectoryLinkLocator = By.xpath("//*[@id=\"menu_directory_viewDirectory\"]");
	public By searchButtonLocator = By.xpath("//*[@id=\"searchBtn\"]");

}
