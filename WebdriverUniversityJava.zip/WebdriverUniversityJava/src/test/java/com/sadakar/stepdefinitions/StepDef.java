package com.sadakar.stepdefinitions;

import java.time.Duration;
import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.testng.Assert;
//import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;

import com.sadakar.common.BasePage;
import io.cucumber.java.en.Given;

public class StepDef extends BasePage {
	
	private String mainWindowHandle;
    
    @Given("I navigate to url")
    public void i_navigate_to_url() {
//        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
//        driver = new ChromeDriver();
//        driver.get(url);
        driver.get("http://webdriveruniversity.com/index.html");
        mainWindowHandle = driver.getWindowHandle();
    }

    @When("I click on the iframe link")
    public void i_click_on_the_link() {
        WebElement iframeLink = driver.findElement(By.xpath("//h1[text()='IFRAME']"));
        Actions action = new Actions(driver);

        action.moveToElement(iframeLink).click().perform();
//        iframeLink.click();
    }

    @Then("I verify that a new tab has opened and I switch to the new tab")
    public void i_verify_that_a_new_tab_has_opened() {
    	 mainWindowHandle = driver.getWindowHandle();
         for (String handle : driver.getWindowHandles()) {
             if (!handle.equals(mainWindowHandle)) {
                 driver.switchTo().window(handle);
                 break;
             }
         }
         Assert.assertNotEquals(driver.getWindowHandle(), mainWindowHandle);
     }

    @And("I verify that the Image is present")
    public void i_verify_that_the_image_is_present() {
    	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    	WebElement iframe = driver.findElement(By.xpath("//iframe[@id='frame']"));
    	driver.switchTo().frame(iframe);
        WebElement image = driver.findElement(By.xpath("//*[contains(@src,'amp.svg')]"));
        Assert.assertTrue(image.isDisplayed());
    }

    @And("I click the right arrow button")
    public void i_click_the_right_arrow_button() {
        WebElement rightArrowButton = driver.findElement(By.xpath("//a[@data-slide='next']"));
        rightArrowButton.click();
    }

    @Then("I verify that the Images are changing accordingly")
    public void i_verify_that_the_images_are_changing_accordingly() {
        // Implement image verification logic here
        // You may need to keep track of image URLs and verify if they are changing accordingly
    	WebElement secondImage = driver.findElement(By.xpath("//*[contains(@src,'boombox.svg')]"));
    	WebElement thirdImage = driver.findElement(By.xpath("//*[contains(@src,'nintendo.svg')]"));
    	
    	try
    	{
    	if (secondImage.isDisplayed() || thirdImage.isDisplayed()) {
    		System.out.print("Image changed");
    	}
    	}
    	catch(Exception e)
    	{
    		System.out.print("Image not changed");
    	}
    }
}
