import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

@pytest.fixture(scope="module")
def driver():
    # Setup
    driver = webdriver.Chrome()
    driver.implicitly_wait(10)
    yield driver
    # Teardown
    driver.quit()

def test_verify_title(driver):
    driver.get("http://webdriveruniversity.com/index.html")
    assert "WebDriverUniversity" in driver.title

def test_dropdown_checkboxes_radiobuttons(driver):
    driver.find_element(By.LINK_TEXT, "Dropdown, Checkboxes & Radio Buttons").click()
    WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(2))
    driver.switch_to.window(driver.window_handles[1])
    assert "Dropdown, Checkboxe" in driver.title

def test_select_value_from_dropdown(driver):
    dropdown = driver.find_element(By.ID, "dropdowm-menu-1")
    dropdown.click()
    driver.find_element(By.CSS_SELECTOR, "option[value='python']").click()
    assert dropdown.get_attribute("value") == "python"

def test_select_multiple_checkboxes(driver):
    checkboxes = driver.find_elements(By.CSS_SELECTOR, "input[type='checkbox']")
    for checkbox in checkboxes:
        checkbox.click()
    checked_count = len(driver.find_elements(By.CSS_SELECTOR, "input[type='checkbox']:checked"))
    unchecked_count = len(driver.find_elements(By.CSS_SELECTOR, "input[type='checkbox']:not(:checked)"))
    assert checked_count == 3
    assert unchecked_count == 2

def test_select_radio_button(driver):
    radio_button = driver.find_element(By.CSS_SELECTOR, "input[type='radio']")
    radio_button.click()
    checked_count = len(driver.find_elements(By.CSS_SELECTOR, "input[type='radio']:checked"))
    unchecked_count = len(driver.find_elements(By.CSS_SELECTOR, "input[type='radio']:not(:checked)"))
    assert checked_count == 1
    assert unchecked_count == 2
