import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class WebAutomationSteps {
    private WebDriver driver;

    @Given("I launch the URL {string}")
    public void iLaunchTheURL(String url) {
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        driver.get(url);
    }

    @Then("I verify the title of the page is {string}")
    public void iVerifyTheTitleOfThePageIs(String expectedTitle) {
        String actualTitle = driver.getTitle();
        Assert.assertEquals(actualTitle, expectedTitle);
    }

    @When("I click on IFRAME link")
    public void iClickOnIFRAMELink() {
        WebElement iframeLink = driver.findElement(By.linkText("IFRAME"));
        iframeLink.click();
    }

    @Then("I verify that a new tab has opened")
    public void iVerifyThatANewTabHasOpened() {
        String currentWindowHandle = driver.getWindowHandle();
        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(currentWindowHandle)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }
        Assert.assertNotEquals(driver.getWindowHandle(), currentWindowHandle);
    }

    @Then("I verify the image is present")
    public void iVerifyTheImageIsPresent() {
        WebElement image = driver.findElement(By.tagName("img"));
        Assert.assertTrue(image.isDisplayed());
    }

    @When("I click on the right arrow button")
    public void iClickOnTheRightArrowButton() {
        WebElement rightArrowButton = driver.findElement(By.className("right-arrow"));
        rightArrowButton.click();
    }

    @Then("I verify that images are changing accordingly")
    public void iVerifyThatImagesAreChangingAccordingly() {
        // Add your verification logic here
    }

    @Then("I close the browser")
    public void iCloseTheBrowser() {
        driver.quit();
    }
}