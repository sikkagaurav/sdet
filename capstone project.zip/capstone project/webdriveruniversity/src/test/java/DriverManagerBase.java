public class DriverManagerBase {
    private static WebDriver driver;

    public static WebDriver getDriver() {
        if (driver == null) {
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\sikka\\Downloads\\chrome\\chromedriver.exe");
            driver = new ChromeDriver();
        }
        return driver;
    }
}
