import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class StepDefinitions {

    private WebDriver driver;
    private String mainWindowHandle;

    @Given("I launch the URL {string}")
    public void launchURL(String url) {
        // Code to launch the URL
        driver = DriverManager.getDriver(); // Assume driver is initialized and managed by a separate class
        driver.get(url);
    }

    @When("I click on IFRAME link")
    public void clickIFrameLink() {
        // Code to click on IFRAME link
        WebElement iFrameLink = driver.findElement(By.linkText("IFRAME"));
        iFrameLink.click();
    }

    @Then("I verify that new tab has opened and switch to that tab")
    public void verifyAndSwitchToNewTab() {
        // Code to verify and switch to new tab
        mainWindowHandle = driver.getWindowHandle();
        for (String handle : driver.getWindowHandles()) {
            if (!handle.equals(mainWindowHandle)) {
                driver.switchTo().window(handle);
                break;
            }
        }
        Assert.assertNotEquals(driver.getWindowHandle(), mainWindowHandle);
    }

    @Then("I verify that the Image is present and click on right arrow button")
    public void verifyImageAndClickRightArrow() {
        // Code to verify image and click on right arrow button
        WebElement image = driver.findElement(By.cssSelector("img.image-class"));
        Assert.assertTrue(image.isDisplayed());

        WebElement rightArrowButton = driver.findElement(By.cssSelector("button.right-arrow-class"));
        rightArrowButton.click();
        // Code to verify that the images are changing accordingly
    }
}
